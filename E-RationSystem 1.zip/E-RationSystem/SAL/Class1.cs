﻿namespace SAL
{
    public class Class1
    {

    }
}