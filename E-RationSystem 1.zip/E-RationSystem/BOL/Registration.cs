﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOL
{
    public class Registration
    {
        [Key]
        public int Serial_no { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Mobile_No { get; set; }

        public string Adhar_No { get; set; }

        [Required]
        public string Gender { get; set; }

        [Required]
        public DateOnly Date_of_Birth { get; set; }

        [Required]
        public decimal Income { get; set; }

        [Required]
        public int Total_Members { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public int Pincode { get; set; }

    }
}
