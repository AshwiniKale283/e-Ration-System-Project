﻿using BOL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public interface IRegistration
    {
        bool addNewUser(Registration newuser);
        List<Registration> getNewUser();
        Registration getUserbyID(int id);
        bool removeUserbyID(int id);
    }
}
