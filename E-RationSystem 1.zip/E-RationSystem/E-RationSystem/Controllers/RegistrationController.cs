﻿using BOL;
using BLL;
using DAL;
using Microsoft.AspNetCore.Mvc;

namespace E_RationSystem.Controllers
{
    public class RegistrationController : Controller
    {
        private IRegistration _IRegistration;
        public RegistrationController() 
        {
            _IRegistration = new RegistrationDAL();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Registration(Registration newuser)
        {
            Boolean status = _IRegistration.addNewUser(newuser);
            if(status)
            {
                TempData["message"] = "Data Submitted Successfully...Wait For Confirmation";
                return RedirectToAction("Registration", "Consumer");
            }
            else
            {
                TempData["message"] = "Registration not successfull...Retry";
                return View();
            }

          

        }

        public IActionResult Removeuser(int id) 
        {
            bool status = _IRegistration.removeUserbyID(id);
            if (status)
                return RedirectToAction("ShowNewRequest", "Government");
            else
                return RedirectToAction("index", "Government");

        }
    }


}
