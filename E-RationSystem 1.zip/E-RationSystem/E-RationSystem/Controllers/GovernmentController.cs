﻿using BLL;
using BOL;
using DAL;
using Microsoft.AspNetCore.Mvc;

namespace E_RationSystem.Controllers
{
    public class GovernmentController : Controller
    {

        private readonly ILogger<GovernmentController> _logger;
        private IConsumer _IConsumer;
        private IStock _IStock;
        private IDistributor _IDistributor;
        private ISupplier _ISupplier;
        private IRegistration _IRegistration;

        public GovernmentController(ILogger<GovernmentController> logger)
        {
            _logger = logger;
            _IConsumer = new ConsumerDAL();
            _IStock = new StockDAL();
            _IDistributor = new DistributorDAL();
            _ISupplier = new SupplierDAL();
            _IRegistration = new RegistrationDAL();

        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }


        public IActionResult ShowCardHolder()
        {
            if (HttpContext.Session.GetString("government") == "1")
            {
                List<Consumer> user = _IConsumer.getAllConsumer();

                if (user != null)
                {
                    ViewData["consumer"] = user;
                }
            }

            return View();
        }

        public IActionResult ShowNewRequest()
        {
            List<Registration> newuser = _IRegistration.getNewUser();
            if (newuser != null)
            {
                ViewData["newrequest"] = newuser;
            }
            return View();

        }

        public IActionResult ShowStock()
        {
            
                List<Stock> slist = _IStock.getAllStock();

                if (slist != null)
                {
                    ViewData["stocks"] = slist;
                }
            

            return View();
        }

        public IActionResult ShowDistributor()
        {
            if (HttpContext.Session.GetString("government") == "1")
            {
                List<Distributor> user = _IDistributor.getAllDistributor();

                if (user != null)
                {
                    ViewData["distributor"] = user;
                }
            }

            return View();
        }

        public IActionResult ShowSupplier()
        {
            if (HttpContext.Session.GetString("government") == "1")
            {
                List<Supplier> user = _ISupplier.getALLSupplier();

                if (user != null)
                {
                    ViewData["supplier"] = user;
                }
            }

            return View();
        }

        public IActionResult ShowSupplierStock()
        {

            List<Stock> slist = _IStock.getSupplierStock();

            if (slist != null)
            {
                ViewData["stocks"] = slist;
            }


            return View();
        }

        public IActionResult ShowDistributorStock()
        {

            List<Stock> slist = _IStock.getDistributorStock();

            if (slist != null)
            {
                ViewData["stocks"] = slist;
            }


            return View();
        }

        public IActionResult AddUser(int Id)
        {
            Registration r = _IRegistration.getUserbyID(Id);
       
            if (r != null)
            {
                 ViewData["adduser"] = r;
            }
            return View();
            
        }

        [HttpPost]
        public IActionResult AddUser(Consumer consumer)
        {
            bool status = _IConsumer.addNewUser(consumer);
            if (status)
            {
                return RedirectToAction("ShowCardHolder", "Government");
            }
            else
                return RedirectToAction("ShowNewRequest", "Government");
        }

    }
}
