﻿using BLL;
using BOL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DAL
{
    public class RegistrationDAL : IRegistration
    {
        ApplicationContext _context = new ApplicationContext();
        public bool addNewUser(Registration newuser)
        {
            Boolean status = false;
            Registration registration = new Registration()
            {
                Name = newuser.Name,
                Mobile_No = newuser.Mobile_No,
                Adhar_No = newuser.Adhar_No,
                Gender = newuser.Gender,
                Date_of_Birth = newuser.Date_of_Birth,
                Income = newuser.Income,
                Total_Members = newuser.Total_Members,
                Address = newuser.Address,
                Pincode = newuser.Pincode
            };

            _context.registration.Add(registration);
            _context.SaveChanges();
            status = true;
            return status;    
        }

        public List<Registration> getNewUser()
        {
            var user = from u in _context.registration select u;
            return user.ToList();
        }

        public bool removeUserbyID(int id)
        {
            bool status = false;
            var newuser = _context.registration.Where(u => u.Serial_no == id).SingleOrDefault();
            _context.registration.Remove(newuser);
            _context.SaveChanges();
            status = true;
            return status;

        }

        public Registration getUserbyID(int id)
        {
            var user = from u in _context.registration where (u.Serial_no == id) select u;
            Registration r = null;
       
            foreach (var u in user)
            {
                r = new Registration();
                r.Name = u.Name;
                r.Mobile_No = u.Mobile_No;
                r.Adhar_No = u.Adhar_No;
                r.Date_of_Birth = u.Date_of_Birth;
                r.Gender = u.Gender;
                r.Income = u.Income;
                r.Total_Members = u.Total_Members;
                r.Address = u.Address;
                r.Pincode = u.Pincode;
                
                   
            }
            return r;
        }

        /*    public Registration getUserbyID(int id)
            {
                Registration user = _context.registration.Where( u => u.Serial_no == id).Select(r => new Registration(){
                    Name = r.Name,
                    Mobile_No = r.Mobile_No,
                    Adhar_No = r.Adhar_No,
                    Date_of_Birth = r.Date_of_Birth,
                    Gender = r.Gender,
                    Income = r.Income,
                    Total_Members = r.Total_Members,
                    Address = r.Address,
                    Pincode = r.Pincode
                });
                return user;


                  using (var db = new MyContext())
        {
            var query = from u in db.Users
                        orderby u.FirstName
                        select u;

            foreach (var item in query)
            {
                User user = new User();
                user.Id = item.pkUser;
                user.Username = item.Username;
                user.Password = item.Password;
                user.Active = item.Active;

                userList.Add(user);
            }
        }

        return userList;
    }

            }*/
    }
}
