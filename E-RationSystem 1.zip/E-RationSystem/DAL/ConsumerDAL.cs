﻿using BLL;
using BOL;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class ConsumerDAL: IConsumer
    {
        ApplicationContext _context = new ApplicationContext();
        public List<Consumer> getAllConsumer()
        {
            var user = from u in _context.consumer select u;
            return user.ToList();
        }

          public Consumer validateConsumer(String RationId, String password)
          {

              List<Consumer> clist = getAllConsumer();
               if (clist != null)
                {
                 foreach (Consumer c in clist)
                 {
                  
                      if (c.Ration_Id.Equals(RationId) && c.Password.Equals(password))
                         return c;

                 }
              }
              return null;

          }

        /*public Consumer validateConsumer(String RationId, String password)
        {
            var user = from u in _context.consumer where u.Ration_Id == RationId && u.Password == password select u;
            return (Consumer)user;
        }*/

        public Consumer showDetailsByID(String user)
        {
            List<Consumer> clist = getAllConsumer();
            if (clist != null)
            {
                foreach (Consumer c in clist)
                {

                    if (c.Ration_Id.Equals(user))
                        return c;

                }
            }
            return null;

        }

        public bool addNewUser(Consumer consumer)
        {
            Boolean status = false;
            Consumer cons = new Consumer()
            {
                Ration_Id=consumer.Ration_Id,
                Name = consumer.Name,
                Mobile_No = consumer.Mobile_No,
                Adhar_No = consumer.Adhar_No,
                Gender = consumer.Gender,
                Date_of_Birth = consumer.Date_of_Birth,
                Income = consumer.Income,
                Total_Members = consumer.Total_Members,
                Password=consumer.Password,
                Address = consumer.Address,
                Pincode = consumer.Pincode
            };

            _context.consumer.Add(cons);
            _context.SaveChanges();
            status = true;
            return status;
        }
    }
}
