﻿using Microsoft.AspNetCore.Mvc;

namespace E_RationSystem.Controllers
{
    public class RegistrationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
