﻿using Microsoft.AspNetCore.Mvc;

namespace E_RationSystem.Controllers
{
    public class DistributorController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
